import type { ColumnDefinition, DropdownOptionsMap, SubOffice, WorkOrder } from '../types.ts';

export const INITIAL_OFFICES: SubOffice[] = [
  {
    id: 'off-arar',
    name: 'مكتب عرعر',
    code: 'ARAR',
    region: 'منطقة الحدود الشمالية',
    contractors: ['فصول السنة', 'الوبران', 'الاداء المتوازن', 'القرش', 'بن دلامة'],
    consultants: ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    defaultConsultant: 'الحامد'
  },
  {
    id: 'off-rafha',
    name: 'مكتب رفحاء',
    code: 'RAFHA',
    region: 'منطقة الحدود الشمالية',
    contractors: ['فصول السنة', 'الاداء المتوازن', 'العلاوي'],
    consultants: ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    defaultConsultant: 'الحامد'
  },
  {
    id: 'off-turaif',
    name: 'مكتب طريف',
    code: 'TURAIF',
    region: 'منطقة الحدود الشمالية',
    contractors: ['الجلهمي', 'اكتاف', 'امدادات التقنية', 'اوناس'],
    consultants: ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    defaultConsultant: 'الحامد'
  },
  {
    id: 'off-olaiqila',
    name: 'مكتب العويقيلة',
    code: 'OLAIQILA',
    region: 'منطقة الحدود الشمالية',
    contractors: ['اكتاف'],
    consultants: ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    defaultConsultant: 'الحامد'
  }
];

export const INITIAL_COLUMNS: ColumnDefinition[] = [
  {
    id: 'office',
    field: 'office',
    key: 'office',
    title: 'المكتب',
    type: 'select',
    visible: true,
    order: 1,
    width: '130px',
    minWidth: '120px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'office'
  },
  {
    id: 'contractor',
    field: 'contractor',
    key: 'contractor',
    title: 'المقاول',
    type: 'select',
    visible: true,
    order: 2,
    width: '185px',
    minWidth: '165px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'contractor'
  },
  {
    id: 'consultant',
    field: 'consultant',
    key: 'consultant',
    title: 'الاستشاري',
    type: 'select',
    visible: true,
    order: 3,
    width: '175px',
    minWidth: '155px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'consultant'
  },
  {
    id: 'workOrderNumber',
    field: 'workOrderNumber',
    key: 'workOrderNumber',
    title: 'رقم امر العمل',
    type: 'text',
    visible: true,
    order: 4,
    width: '160px',
    minWidth: '145px',
    isRemovable: false,
    hasDropdown: false
  },
  {
    id: 'workOrderCode',
    field: 'workOrderCode',
    key: 'workOrderCode',
    title: 'نوع امر العمل',
    type: 'select',
    visible: true,
    order: 5,
    width: '130px',
    minWidth: '115px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'workOrderCode'
  },
  {
    id: 'photosFile',
    field: 'photosFile',
    key: 'photosFile',
    title: 'ملف الصور',
    type: 'files',
    visible: true,
    order: 6,
    width: '165px',
    minWidth: '155px',
    isRemovable: false,
    hasDropdown: false,
    dropdownKey: 'photosFile'
  },
  {
    id: 'attachmentStatus',
    field: 'attachmentStatus',
    key: 'attachmentStatus',
    title: 'حالة الارفاق',
    type: 'select',
    visible: true,
    order: 7,
    width: '165px',
    minWidth: '150px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'attachmentStatus'
  },
  {
    id: 'qualityNotes',
    field: 'qualityNotes',
    key: 'qualityNotes',
    title: 'الملاحظات',
    type: 'text',
    visible: true,
    order: 8,
    width: '250px',
    minWidth: '210px',
    isRemovable: false,
    hasDropdown: false
  },
  {
    id: 'pdcAudit',
    field: 'pdcAudit',
    key: 'pdcAudit',
    title: 'تدقيق PDC',
    type: 'text',
    visible: true,
    order: 9,
    width: '165px',
    minWidth: '150px',
    isRemovable: false,
    hasDropdown: false
  },
  {
    id: 'constructionAudit',
    field: 'constructionAudit',
    key: 'constructionAudit',
    title: 'تدقيق الانشاءات',
    type: 'text',
    visible: true,
    order: 10,
    width: '165px',
    minWidth: '150px',
    isRemovable: false,
    hasDropdown: false
  },
  {
    id: 'procedure155Status',
    field: 'procedure155Status',
    key: 'procedure155Status',
    title: 'تدقيق المساندة الفنية',
    type: 'select',
    visible: true,
    order: 11,
    width: '190px',
    minWidth: '175px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'procedure155Status'
  },
  {
    id: 'statusSyncTime',
    field: 'statusSyncTime',
    key: 'statusSyncTime',
    title: 'مزامنة التدقيق',
    type: 'text',
    visible: true,
    order: 12,
    width: '165px',
    minWidth: '150px',
    isRemovable: false,
    hasDropdown: false
  },
  {
    id: 'procedure155',
    field: 'procedure155',
    key: 'procedure155',
    title: 'حالة إجراء 155',
    type: 'select',
    visible: true,
    order: 13,
    width: '165px',
    minWidth: '150px',
    isRemovable: false,
    hasDropdown: true,
    dropdownKey: 'procedure155'
  },
  {
    id: 'procedureSyncTime',
    field: 'procedureSyncTime',
    key: 'procedureSyncTime',
    title: 'مزامنة إجراء 155',
    type: 'text',
    visible: true,
    order: 14,
    width: '165px',
    minWidth: '150px',
    isRemovable: false,
    hasDropdown: false
  }
];

export const INITIAL_DROPDOWN_OPTIONS: DropdownOptionsMap = {
  office: ['مكتب عرعر', 'مكتب رفحاء', 'مكتب طريف', 'مكتب العويقيلة'],
  contractor: [
    'فصول السنة',
    'الوبران',
    'الاداء المتوازن',
    'القرش',
    'بن دلامة',
    'العلاوي',
    'الجلهمي',
    'اكتاف',
    'امدادات التقنية',
    'اوناس'
  ],
  consultant: ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
  workOrderCode: ['801', '401', '912'],
  photoDocumentation: ['مكتمل', 'قيد الإنشاء', 'غير مكتمل'],
  consultantForms: ['مكتمل', 'قيد الإنشاء', 'غير مكتمل'],
  consultantClearanceForms: ['مكتمل', 'قيد الإنشاء', 'غير مكتمل'],
  form190: ['مكتمل', 'قيد الإنشاء', 'غير مكتمل'],
  form200: ['مكتمل', 'قيد الإنشاء', 'غير مكتمل'],
  inspectionForm: ['مكتمل', 'قيد الإنشاء', 'غير مكتمل'],
  procedure155Status: ['مؤهل للاغلاق', 'غير مؤهل للاغلاق'],
  procedure155: ['مؤهل للاغلاق ( معتمد )', 'غير مؤهل للأغلاق'],
  officeContractors: {
    'مكتب عرعر': ['فصول السنة', 'الوبران', 'الاداء المتوازن', 'القرش', 'بن دلامة'],
    'مكتب رفحاء': ['فصول السنة', 'الاداء المتوازن', 'العلاوي'],
    'مكتب طريف': ['الجلهمي', 'اكتاف', 'امدادات التقنية', 'اوناس'],
    'مكتب العويقيلة': ['اكتاف']
  },
  officeConsultants: {
    'مكتب عرعر': ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    'مكتب رفحاء': ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    'مكتب طريف': ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت'],
    'مكتب العويقيلة': ['الحامد', 'المحايد', 'الصخرة المشرفة', 'سعود كونسلت']
  },
  attachmentStatus: [
    'جاهز للارفاق الكامل',
    'جاهز لارفاق صور العداد',
    'جاهز لارفاق صور الخفريات',
    'جاهز لارفاق صور المعدات',
    'جاهز لارفاق صور الهوائي',
    'غير جاهز للارفاق'
  ]
};

export const INITIAL_WORK_ORDERS: WorkOrder[] = [
  {
    id: 'wo-101',
    workOrderNumber: 'WO-2026-001',
    workOrderCode: 'ARAR-HV-901',
    office: 'مكتب عرعر',
    contractor: 'فصول السنة',
    consultant: 'الحامد',
    executionStatus: 'قيد التنفيذ',
    photoDocumentation: 'مكتمل',
    consultantForms: 'مكتمل',
    consultantClearanceForms: 'مكتمل',
    form190: 'مكتمل',
    form200: 'مكتمل',
    inspectionForm: 'مكتمل',
    procedure155Status: 'مؤهل للاغلاق',
    auditSyncStatus: 'محفوظ ومزامن'
  },
  {
    id: 'wo-102',
    workOrderNumber: 'WO-2026-002',
    workOrderCode: 'RAFHA-LV-402',
    office: 'مكتب رفحاء',
    contractor: 'الاداء المتوازن',
    consultant: 'المحايد',
    executionStatus: 'مكتمل',
    photoDocumentation: 'قيد الإنشاء',
    consultantForms: 'قيد الإنشاء',
    consultantClearanceForms: 'غير مكتمل',
    form190: 'قيد الإنشاء',
    form200: 'غير مكتمل',
    inspectionForm: 'قيد الإنشاء',
    procedure155Status: 'غير مؤهل للاغلاق',
    auditSyncStatus: 'محفوظ ومزامن'
  }
];

export function ensurePhotosFileColumn(_cols?: ColumnDefinition[]): ColumnDefinition[] {
  return INITIAL_COLUMNS.map((col, idx) => ({
    ...col,
    order: idx + 1,
    visible: true
  }));
}
