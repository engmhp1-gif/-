import type { SubOffice, WorkOrder, ColumnDefinition, DropdownOptionsMap } from '../types.ts';
import {
  DEFAULT_OFFICE_CONTRACTORS,
  DEFAULT_CONSULTANTS,
  DEFAULT_OFFICE_CONSULTANTS
} from '../services/contractorService.ts';

export const INITIAL_OFFICES: SubOffice[] = [
  {
    id: 'office-arar',
    name: 'مكتب عرعر',
    code: 'ARR-01',
    region: 'منطقة الحدود الشمالية - عرعر',
    manager: 'إدارة مكتب عرعر',
    contactNumber: '0146620000',
    description: 'المكتب الرئيسي لمتابعة وتدقيق أوامر العمل في قطاع عرعر',
    contractors: [...DEFAULT_OFFICE_CONTRACTORS['مكتب عرعر']],
    defaultContractor: DEFAULT_OFFICE_CONTRACTORS['مكتب عرعر'][0],
    consultants: [...DEFAULT_CONSULTANTS],
    defaultConsultant: DEFAULT_CONSULTANTS[0]
  },
  {
    id: 'office-rafha',
    name: 'مكتب رفحاء',
    code: 'RFH-02',
    region: 'منطقة الحدود الشمالية - رفحاء',
    manager: 'إدارة مكتب رفحاء',
    contactNumber: '0146760000',
    description: 'مكتب متابعة وتدقيق أوامر العمل في قطاع رفحاء',
    contractors: [...DEFAULT_OFFICE_CONTRACTORS['مكتب رفحاء']],
    defaultContractor: DEFAULT_OFFICE_CONTRACTORS['مكتب رفحاء'][0],
    consultants: [...DEFAULT_CONSULTANTS],
    defaultConsultant: DEFAULT_CONSULTANTS[0]
  },
  {
    id: 'office-turaif',
    name: 'مكتب طريف',
    code: 'TRF-03',
    region: 'منطقة الحدود الشمالية - طريف',
    manager: 'إدارة مكتب طريف',
    contactNumber: '0146530000',
    description: 'مكتب متابعة وتدقيق أوامر العمل في قطاع طريف',
    contractors: [...DEFAULT_OFFICE_CONTRACTORS['مكتب طريف']],
    defaultContractor: DEFAULT_OFFICE_CONTRACTORS['مكتب طريف'][0],
    consultants: [...DEFAULT_CONSULTANTS],
    defaultConsultant: DEFAULT_CONSULTANTS[0]
  },
  {
    id: 'office-markaz',
    name: 'مكتب العويقيلة',
    code: 'AWQ-04',
    region: 'منطقة الحدود الشمالية - العويقيلة',
    manager: 'إدارة مكتب العويقيلة',
    contactNumber: '0146690000',
    description: 'مكتب متابعة وتدقيق أوامر العمل في قطاع العويقيلة',
    contractors: [...DEFAULT_OFFICE_CONTRACTORS['مكتب العويقيلة']],
    defaultContractor: DEFAULT_OFFICE_CONTRACTORS['مكتب العويقيلة'][0],
    consultants: [...DEFAULT_CONSULTANTS],
    defaultConsultant: DEFAULT_CONSULTANTS[0]
  }
];

/**
 * The 14 Canonical Approved Platform Columns (Column 15 removed permanently).
 */
export const INITIAL_COLUMNS: ColumnDefinition[] = [
  {
    id: 'office',
    field: 'office',
    title: '1. المكتب',
    order: 1,
    hasDropdown: true,
    dropdownKey: 'office',
    isRemovable: false,
    minWidth: '125px'
  },
  {
    id: 'contractor',
    field: 'contractor',
    title: '2. المقاول',
    order: 2,
    hasDropdown: true,
    dropdownKey: 'contractor',
    isRemovable: false,
    minWidth: '135px'
  },
  {
    id: 'consultant',
    field: 'consultant',
    title: '3. الاستشاري',
    order: 3,
    hasDropdown: true,
    dropdownKey: 'consultant',
    isRemovable: false,
    minWidth: '130px'
  },
  {
    id: 'workOrderNumber',
    field: 'workOrderNumber',
    title: '4. رقم امر العمل',
    order: 4,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '135px'
  },
  {
    id: 'workOrderCode',
    field: 'workOrderCode',
    title: '5. نوع امر العمل',
    order: 5,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '115px'
  },
  {
    id: 'photosFile',
    field: 'photosFile',
    title: '6. ملف الصور',
    order: 6,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '150px'
  },
  {
    id: 'attachmentStatus',
    field: 'attachmentStatus',
    title: '7. حالة الارفاق',
    order: 7,
    hasDropdown: true,
    dropdownKey: 'attachmentStatus',
    isRemovable: false,
    minWidth: '175px'
  },
  {
    id: 'qualityNotes',
    field: 'qualityNotes',
    title: '8. الملاحظات',
    order: 8,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '210px'
  },
  {
    id: 'pdcAudit',
    field: 'pdcAudit',
    title: '9. تدقيق PDC',
    order: 9,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '185px'
  },
  {
    id: 'constructionAudit',
    field: 'constructionAudit',
    title: '10. تدقيق الإنشاءات',
    order: 10,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '185px'
  },
  {
    id: 'procedure155Status',
    field: 'procedure155Status',
    title: '11. تدقيق المساندة الفنية',
    order: 11,
    hasDropdown: true,
    dropdownKey: 'procedure155Status',
    isRemovable: false,
    minWidth: '190px'
  },
  {
    id: 'statusSyncTime',
    field: 'statusSyncTime',
    title: '12. مزامنة التدقيق',
    order: 12,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '185px'
  },
  {
    id: 'procedure155',
    field: 'procedure155',
    title: '13. إجراء 155',
    order: 13,
    hasDropdown: true,
    dropdownKey: 'procedure155',
    isRemovable: false,
    minWidth: '150px'
  },
  {
    id: 'procedureSyncTime',
    field: 'procedureSyncTime',
    title: '14. مزامنة الإجراء',
    order: 14,
    hasDropdown: false,
    isRemovable: false,
    minWidth: '165px'
  }
];

export const CANONICAL_ALLOWED_COLUMN_FIELDS = new Set<string>(
  INITIAL_COLUMNS.map((c) => String(c.field || c.id))
);

/**
 * Enforces the 14 canonical columns across all tables, backups, and Excel imports.
 * Never imports or retains any column outside the 14 approved columns (and permanently excludes column 15).
 */
export function ensurePhotosFileColumn(columns?: ColumnDefinition[]): ColumnDefinition[] {
  if (!Array.isArray(columns) || columns.length === 0) {
    return INITIAL_COLUMNS.map((c, idx) => ({ ...c, order: idx + 1 }));
  }

  const byField = new Map<string, ColumnDefinition>();
  for (const col of columns) {
    if (!col) continue;
    const field = String(col.field || col.id || '').trim();
    if (!field || !CANONICAL_ALLOWED_COLUMN_FIELDS.has(field)) continue;
    byField.set(field, col);
  }

  return INITIAL_COLUMNS.map((stdCol, idx) => {
    const field = String(stdCol.field || stdCol.id);
    const existing = byField.get(field);
    return {
      ...stdCol,
      ...(existing
        ? {
            width: existing.width ?? stdCol.width,
            minWidth: existing.minWidth ?? stdCol.minWidth,
            visible: existing.visible !== false
          }
        : {}),
      id: stdCol.id,
      field: stdCol.field,
      title: stdCol.title,
      order: idx + 1,
      isCustom: false,
      isRemovable: false
    };
  });
}

export const INITIAL_DROPDOWN_OPTIONS: DropdownOptionsMap = {
  office: ['مكتب عرعر', 'مكتب رفحاء', 'مكتب طريف', 'مكتب العويقيلة'],
  contractor: [
    'فصول السنة',
    'الوبران',
    'الاداء المتوازن',
    'القرش',
    'بن دلامة',
    'العلاوي',
    'الجلهمي',
    'اكتاف',
    'امدادات التقنية',
    'اوناس'
  ],
  consultant: [...DEFAULT_CONSULTANTS],
  attachmentStatus: [
    'جاهز للارفاق الكامل',
    'جاهز لارفاق صور العداد',
    'جاهز لارفاق صور الخفريات',
    'جاهز لارفاق صور المعدات',
    'جاهز لارفاق صور الهوائي',
    'غير جاهز للارفاق'
  ],
  photoDocumentation: ['مكتمل', 'غير مكتمل', 'لا ينطبق', 'مكتمل مع ملاحظات'],
  consultantForms: ['مكتمل', 'غير مكتمل', 'لا ينطبق', 'مكتمل مع ملاحظات'],
  consultantClearanceForms: ['مكتمل', 'غير مكتمل', 'لا ينطبق', 'مكتمل مع ملاحظات'],
  form190: ['مكتمل', 'غير مكتمل', 'لا ينطبق', 'مكتمل مع ملاحظات'],
  form200: ['مكتمل', 'غير مكتمل', 'لا ينطبق', 'مكتمل مع ملاحظات'],
  inspectionForm: ['مكتمل', 'غير مكتمل', 'لا ينطبق', 'مكتمل مع ملاحظات'],
  procedure155Status: [
    'مؤهل للاغلاق ( معتمد )',
    'غير مؤهل للأغلاق',
    'بانتظار استيفاء الملاحظات',
    'قيد التدقيق الفني'
  ],
  procedure155: [
    'تم الاجراء',
    'مؤهل للاغلاق ( معتمد )',
    'جاري الرفع على النظام',
    'بانتظار استيفاء الملاحظات',
    'غير مؤهل للأغلاق'
  ],
  boqModification: [
    'مطابق للمقايسة المعتمدة',
    'نعم - تم اعتماد تعديل المقايسة',
    'نعم - بانتظار اعتماد التعديل',
    'لا يوجد تعديل مطلوب'
  ],
  officeContractors: { ...DEFAULT_OFFICE_CONTRACTORS },
  officeConsultants: { ...DEFAULT_OFFICE_CONSULTANTS }
};

export const INITIAL_WORK_ORDERS: WorkOrder[] = [];
