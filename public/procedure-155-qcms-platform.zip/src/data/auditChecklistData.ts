import type {
  AuditChecklistCategoryKey,
  AuditSectionCategoryData,
  WorkOrder,
  WorkOrderAuditColumnData
} from '../types.ts';

export type AuditCategoryKey = AuditChecklistCategoryKey;

export interface AuditCategoryMeta {
  id: string;
  key: AuditCategoryKey;
  title: string;
  shortTitle: string;
  description: string;
  icon: string;
  itemCount: number;
  items: string[];
}

export const AUDIT_CATEGORIES_META: AuditCategoryMeta[] = [
  {
    id: 'cat-1',
    key: 'stationRoom',
    title: 'غرفة المحطة',
    shortTitle: 'غرفة المحطة',
    description: 'التحقق من الأعمال المدنية والإنشائية والسلامة لغرفة محطة التوزيع',
    icon: 'stationRoom',
    itemCount: 12,
    items: [
      'نظافة غرفة المحطة وخلوها من المخلفات والأنقاض',
      'سلامة الأبواب والفتحات التهوية والشبك الحمائي',
      'تركيب اللوحات التحذيرية ولوحة بيانات المحطة',
      'جودة الدهانات الداخلية والخارجية والعزل المائي للأسقف',
      'سلامة الخنادق والأغطية المعدنية لمسارات الكابلات',
      'إغلاق فتحات دخول الكابلات بمواد مانعة للرطوبة والقوارض',
      'توفير الإضاءة الداخلية ومفاتيح التشغيل السليمة',
      'وجود طفاية الحريق في مكانها المخصص وصلاحيتها',
      'مطابقة أبعاد الغرفة للمخططات الهندسية المعتمدة',
      'سلامة المنحدر الخارجي والدرج وأعمال البردورات',
      'استواء الأرضيات الخرسانية وعدم وجود تشققات',
      'تثبيت مخطط الدائرة الأحادية (Single Line Diagram) داخل الغرفة'
    ]
  },
  {
    id: 'cat-2',
    key: 'hvSwitchgear',
    title: 'وحدة الربط الحلقي (RMU / الجهد المتوسط)',
    shortTitle: 'وحدة الربط RMU',
    description: 'فحص تركيب وتوصيل واختبار لوحة الجهد المتوسط ووحدة الربط الحلقي',
    icon: 'hvSwitchgear',
    itemCount: 11,
    items: [
      'تثبيت وحدة الربط الحلقي (RMU) على القاعدة بشكل مستوٍ ومحكم',
      'سلامة مؤشر غاز SF6 وضغط الغاز في المنطقة الخضراء',
      'توصيل تأريض جسم الوحدة مع شبكة التأريض الرئيسية',
      'تركيب رؤوس نهاية كابلات الجهد المتوسط بشكل صحيح',
      'تركيب مبينات الأعطال الأرضية (EFI) وربط حساسات الكابلات',
      'ترقيم السكاكين والقواطع وكتابة أسماء المغذيات بوضوح',
      'إحكام إغلاق أغطية حجرات الكابلات وتأمين الأقفال',
      'نظافة الوحدة وخلوها من الخدوش أو الصدأ',
      'توفر ذراع التشغيل الخاص بالوحدة في مكانه',
      'اجتياز اختبارات الجهد والعزل ومطابقة نموذج الفحص',
      'تطابق بيانات لوحة الاسم (Nameplate) مع أمر العمل والمقايسة'
    ]
  },
  {
    id: 'cat-3',
    key: 'transformerSubstation',
    title: 'محول التوزيع والقدرة',
    shortTitle: 'محول التوزيع',
    description: 'تدقيق تركيب المحول ومستوى الزيت أو العزل والتوصيلات والحماية',
    icon: 'transformerSubstation',
    itemCount: 11,
    items: [
      'مطابقة قدرة المحول ورقمه التسلسلي مع أمر العمل ونموذج 190',
      'استواء المحول على القاعدة الخرسانية وتثبيت العجلات أو القواعد',
      'عدم وجود أي تهريب للزيت حول الزعانف أو البوشنجات أو الصمامات',
      'فحص مستوى الزيت ومؤشر درجة الحرارة وصلاحية السليكا جل',
      'ضبط مغير الجهد (Tap Changer) على الوضع المعتمد',
      'توصيل تأريض جسم المحول ونقطة التعادل بشكل مستقل ومحكم',
      'سلامة عوازل ومربط كابلات الجهد المتوسط والمنخفض',
      'تركيب الأغطية العازلة والحماية على أطراف التوصيل',
      'نظافة المحول وسلامة الطلاء الخارجي',
      'توفر لوحة البيانات واللوحات التحذيرية على المحول',
      'إرفاق شهادة اختبار المحول ونموذج الفحص الميداني'
    ]
  },
  {
    id: 'cat-4',
    key: 'lvPanel',
    title: 'لوحة التوزيع للجهد المنخفض (LV Panel)',
    shortTitle: 'لوحة الجهد المنخفض',
    description: 'فحص لوحة الجهد المنخفض والقواطع والفيوزات وترقيم الكابلات',
    icon: 'lvPanel',
    itemCount: 11,
    items: [
      'تثبيت لوحة الجهد المنخفض بإحكام واستواء تام على القاعدة',
      'سلامة القاطع الرئيسي وقواعد المصهرات (Fuse Switches)',
      'تركيب المصهرات بالتيار المقنن المناسب لكل مغذٍّ',
      'ربط كابلات التغذية الخارجة بمسامير وعزم الشد القياسي',
      'تركيب محولات التيار (CTs) وأجهزة القياس إن وجدت',
      'ترقيم كافة المغذيات الخارجة وكتابة اتجاهات التغذية',
      'توصيل بارة التأريض وبارة التعادل بشكل سليم',
      'إغلاق فتحات الكابلات السفلية لمنع دخول الأتربة والقوارض',
      'سلامة الحواجز العازلة بين الفازات داخل اللوحة',
      'سلامة باب اللوحة والأقفال والدهان الخارجي',
      'مطابقة توزيع الأحمال على الفازات الثلاث'
    ]
  },
  {
    id: 'cat-5',
    key: 'subDistributionPanel',
    title: 'لوحة التوزيع الفرعية (Pillar / Minipillar)',
    shortTitle: 'لوحة التوزيع الفرعية',
    description: 'تدقيق تركيب كبائن التوزيع الفرعية والمينيبيلر والتوصيلات',
    icon: 'subDistributionPanel',
    itemCount: 11,
    items: [
      'تثبيت لوحة التوزيع الفرعية (Minipillar) على القاعدة الخرسانية',
      'سلامة هيكل اللوحة الخارجي وخلوه من الانبعاجات أو الصدأ',
      'تركيب وترتيب كابلات الدخول والخروج مع الكلبسات المخصصة',
      'إحكام شد نهايات الكابلات (Lugs) وعدم وجود ارتخاء أو سخونة',
      'تركيب العوازل الفاصلة والفيوزات بالقدرات الصحيحة',
      'تأريض جسم الكابينة مع قضيب التأريض المعتمد',
      'وضع رقم اللوحة ولوحة التحذير الخارجية بوضوح',
      'ردم وتسوية المنطقة المحيطة بالقاعدة وإزالة المخلفات',
      'تعبئة قاعدة اللوحة بالرمل النظيف والطبقة الأسمنتية العلوية',
      'سلامة أقفال الأبواب والمفصلات',
      'توثيق صور اللوحة من الداخل والخارج قبل وبعد الإغلاق'
    ]
  },
  {
    id: 'cat-6',
    key: 'stationFoundations',
    title: 'قواعد المحطات والمعدات الخرسانية',
    shortTitle: 'القواعد الخرسانية',
    description: 'التحقق من جودة القواعد الخرسانية الجاهزة أو المصبوبة للمعدات',
    icon: 'stationFoundations',
    itemCount: 10,
    items: [
      'مطابقة أبعاد ومناسيب القاعدة الخرسانية للمواصفات الفنية',
      'خلو الخرسانة من التعشيش أو الشروخ أو الكسور',
      'طلاء الأجزاء المدفونة والظاهرة بالعزل البيتوميني والدهان المعتمد',
      'سلامة فتحات ومواسير دخول الكابلات داخل القاعدة',
      'استواء السطح العلوي للقاعدة بميزان الماء',
      'تركيب مسامير التثبيت (Anchor Bolts) في مواقعها الصحيحة',
      'الدمك الجيد للتربة أسفل وحول القاعدة الخرسانية',
      'مراعاة الارتداد النظامي عن المباني والطرق',
      'توفير الحماية الكافية للقاعدة من تجمع مياه الأمطار',
      'توثيق صور القاعدة قبل وبعد تركيب المعدة عليها'
    ]
  },
  {
    id: 'cat-7',
    key: 'enclosures',
    title: 'الحاويات والكبائن المعدنية والفيبرجلاس',
    shortTitle: 'الحاويات والكبائن',
    description: 'فحص الحاويات الخارجية للمحطات المدمجة وكبائن العدادات',
    icon: 'enclosures',
    itemCount: 10,
    items: [
      'سلامة الهيكل الخارجي للحاوية وعدم وجود أي تلفيات',
      'كفاءة فتحات التهوية والفلاتر المانعة لدخول الغبار والحشرات',
      'إحكام إغلاق الأبواب وسلامة الجوانات المطاطية المانعة للمياه',
      'ربط جميع الأجزاء المعدنية للحاوية والأبواب بشبكة التأريض',
      'تثبيت لوحات التحذير والأرقام التعريفية على جميع الواجهات',
      'سلامة السقف وميلان تصريف مياه الأمطار',
      'نظافة الحاوية من الداخل والخارج',
      'سلامة الأقفال الميكانيكية ومقابض الأبواب',
      'تثبيت الحاوية على القاعدة الخرسانية بجميع المسامير',
      'توثيق صور شاملة لجميع جوانب الحاوية'
    ]
  },
  {
    id: 'cat-8',
    key: 'protectionBollards',
    title: 'مصدات الحماية والأسوار التحذيرية',
    shortTitle: 'مصدات الحماية',
    description: 'فحص تركيب مصدات الحماية المعدنية والخرسانية حول المعدات',
    icon: 'protectionBollards',
    itemCount: 10,
    items: [
      'تركيب مصدات الحماية (Bollards) حول المحطة أو اللوحة المعرضة للمركبات',
      'مطابقة المسافات البينية وارتفاع المصدات للمواصفات المعتمدة',
      'تثبيت المصدات بقواعد خرسانية متينة ومستوية',
      'دهان المصدات باللون الأصفر والأسود التحذيري العاكس',
      'تعبئة المواسير المعدنية للمصدات بالخرسانة',
      'تركيب الأغطية العلوية للمصدات أو تشطيبها بشكل نصف كروي',
      'عدم إعاقة المصدات لفتح أبواب المحطة أو الصيانة',
      'خلو المصدات من الصدأ أو تقشر الدهان',
      'نظافة الموقع حول المصدات وإعادة الوضع لأصله',
      'توثيق صور واضحة لمصدات الحماية بعد التركيب'
    ]
  },
  {
    id: 'cat-9',
    key: 'stationEarthing',
    title: 'شبكة التأريض والحماية الأرضية',
    shortTitle: 'شبكة التأريض',
    description: 'تدقيق تنفيذ شبكة التأريض وقضبان النحاس وقياس مقاومة الأرضي',
    icon: 'stationEarthing',
    itemCount: 12,
    items: [
      'دق قضبان التأريض النحاسية بالعمق والعدد المحدد بالمواصفات',
      'استخدام موصلات النحاس بالمقاطع القياسية المعتمدة',
      'جودة اللحام الحراري (Cadweld) أو المرابط الميكانيكية المعتمدة',
      'تركيب غرف التفتيش الأرضية (Earth Pits) مع الأغطية المعتمدة',
      'قياس مقاومة التأريض والتأكد من عدم تجاوز القيمة المسموحة',
      'فصل تأريض الجهد المتوسط عن تأريض التعادل عند الاقتضاء',
      'تأريض الأبواب والهياكل المعدنية بشريط نحاسي مرن (Braided)',
      'حماية موصلات التأريض الصاعدة على الأعمدة أو الجدران بمواسير PVC',
      'وضع علامات تعريفية على نقاط فصل واختبار التأريض',
      'ردم حفر التأريض بتربة ناعمة ومعالجتها لتحسين التوصيلية',
      'إرفاق قراءة جهاز فحص التأريض بالصور الواضحة',
      'مطابقة تنفيذ التأريض للمخطط الهندسي المعتمد'
    ]
  },
  {
    id: 'cat-10',
    key: 'boxesAndMeters',
    title: 'صناديق العدادات والقواطع واللوحات',
    shortTitle: 'صناديق العدادات',
    description: 'تدقيق تركيب صناديق العدادات الذكية والقواطع وميزان الاستواء',
    icon: 'boxesAndMeters',
    itemCount: 12,
    items: [
      'تركيب صندوق العداد على الارتفاع القياسي المعتمد من سطح الأرض',
      'ضبط استواء الصندوق أفقياً ورأسياً والتوثيق بصورة ميزان الماء',
      'تثبيت الصندوق بالمسامير والخوابير المعتمدة بإحكام',
      'سلامة العداد الذكي والقاطع الحراري وملاءمة سعة القاطع للطلب',
      'ترتيب الأسلاك والكابلات داخل الصندوق وتركيب الجلندات (Glands)',
      'إحكام شد أطراف التوصيل على العداد والقاطع وبارة التجميع',
      'توصيل سلك التأريض بصندوق العداد وقضيب التأريض',
      'كتابة رقم العداد ورقم الاشتراك بوضوح على الصندوق',
      'سلامة نافذة القراءة وأقفال صندوق العداد',
      'نظافة الصندوق من الداخل والخارج وإزالة بقايا الأسلاك',
      'سد الفتحات غير المستخدمة أسفل الصندوق',
      'التقاط الصور الإلزامية للعداد والقاطع والتأريض وميزان الماء'
    ]
  },
  {
    id: 'cat-11',
    key: 'overheadPoles',
    title: 'الأعمدة الكهربائية للشبكات الهوائية',
    shortTitle: 'الأعمدة الهوائية',
    description: 'فحص حفر وتركيب واستقامة الأعمدة الفولاذية أو الخرسانية',
    icon: 'overheadPoles',
    itemCount: 11,
    items: [
      'مطابقة عمق حفرة العمود للمواصفات القياسية حسب طول العمود',
      'استقامة العمود رأسياً والتأكد من اصطفاف الأعمدة في المسار',
      'صب القاعدة الخرسانية حول العمود بالأبعاد والارتفاع المعتمد',
      'طلاء الجزء السفلي من العمود الفولاذي بمادة البيتومين العازلة',
      'تركيب الحوامل (Cross-arms) والملازم والعوازل بشكل سليم',
      'ترقيم الأعمدة وتركيب لوحات التحذير (خطر الموت)',
      'تركيب مانعات التسلق على الأعمدة حسب المواصفات',
      'تأريض العمود وربطه بموصل التأريض الأرضي',
      'سلامة جسم العمود وخلوه من الانحناء أو الصدأ',
      'إغلاق قمة العمود بالغطاء العلوي المخصص',
      'توثيق صور الحفر والصب والعمود بعد التركيب'
    ]
  },
  {
    id: 'cat-12',
    key: 'conductors',
    title: 'الموصلات الهوائية والكابلات المعزولة (ABC)',
    shortTitle: 'الموصلات الهوائية',
    description: 'تدقيق شد الموصلات الهوائية والارتخاء والربط على العوازل',
    icon: 'conductors',
    itemCount: 11,
    items: [
      'مطابقة نوع ومقطع الموصلات للمقايسة المعتمدة',
      'ضبط ارتخاء الموصلات (Sag) ليكون متساوياً في جميع الفازات',
      'تحقيق الخلوص النظامي الآمن عن الأرض والمباني والأشجار',
      'استخدام ملازم الشد والتعليق والوصلات المعتمدة',
      'خلو الموصلات من التنسيل أو الخدوش أثناء السحب',
      'ربط الموصلات على العوازل بطريقة فنية محكمة',
      'تركيب فواصل الفازات أو المخمدات الاهتزازية عند الحاجة',
      'مراعاة تتابع الفازات الصحيح على طول الخط',
      'استخدام الوصلات المعزولة للثقب (IPC) لكابلات ABC بعزم الشد الصحيح',
      'تركيب أغطية نهاية الكابلات الهوائية المعزولة',
      'توثيق صور مسار الشبكة الهوائية والموصلات'
    ]
  },
  {
    id: 'cat-13',
    key: 'stayWire',
    title: 'الشدادات الهوائية ومثبتات الأعمدة (Stay Wires)',
    shortTitle: 'الشدادات الهوائية',
    description: 'فحص تنفيذ الشدادات الأرضية والهوائية وعوازل الشد',
    icon: 'stayWire',
    itemCount: 10,
    items: [
      'تركيب الشدادات في نقاط الزوايا والنهايات لتحقيق التوازن الميكانيكي',
      'دفن كتلة التثبيت الخرسانية (Stay Block) بالعمق والزاوية الصحيحة',
      'تركيب عازل الشداد (Stay Insulator) على الارتفاع القانوني',
      'شد سلك الشداد بشكل متوازن دون إمالة العمود',
      'تركيب الملازم والكشتبانات (Thimbles) بشكل صحيح ومحكم',
      'تركيب الأنبوب التحذيري الأصفر/العاكس (Stay Guard) على الجزء السفلي',
      'طلاء قضيب الشداد المدفون بمادة مانعة للصدأ',
      'عدم إعاقة الشداد لحركة المشاة أو المركبات',
      'إحكام ربط أطراف سلك الشداد وعدم ترك أطراف حادة بارزة',
      'توثيق صور الشداد وعازل الشد والغطاء التحذيري'
    ]
  },
  {
    id: 'cat-14',
    key: 'riserCables',
    title: 'الكابلات الصاعدة على الأعمدة (Riser Cables)',
    shortTitle: 'الكابلات الصاعدة',
    description: 'تدقيق حماية وتثبيت الكابلات الأرضية الصاعدة على الأعمدة الهوائية',
    icon: 'riserCables',
    itemCount: 10,
    items: [
      'حماية الكابل الصاعد بأنبوب فولاذي مجلفن أو PVC ثقيل بالارتفاع القياسي',
      'تثبيت أنبوب الحماية والكابل على العمود بأحزمة ومرابط ستانلس ستيل',
      'إغلاق فوهة أنبوب الحماية العلوية لمنع دخول مياه الأمطار',
      'تنفيذ نهاية الكابل الخارجية (Outdoor Termination) بشكل متقن',
      'تركيب مانعات الصواعق (Surge Arresters) وتأريضها',
      'مراعاة نصف قطر الانحناء المسموح للكابل أسفل العمود',
      'ربط نهاية الكابل بالشبكة الهوائية عبر مشابك ثنائية المعدن (Bimetallic)',
      'وضع بطاقة تعريف الكابل (Cable Tag) بوضوح',
      'تركيب فيوزات الفصل (Drop-out Fuses) للجهد المتوسط',
      'توثيق صور الكابل الصاعد والنهايات ومانعات الصواعق'
    ]
  },
  {
    id: 'cat-15',
    key: 'overheadEquipment',
    title: 'المعدات المركبة على الأعمدة (Pole-Mounted)',
    shortTitle: 'معدات الأعمدة',
    description: 'فحص المحولات والقواطع والسكاكين المركبة على الأعمدة الهوائية',
    icon: 'overheadEquipment',
    itemCount: 10,
    items: [
      'تثبيت حامل المحول أو المعدة على العمود بالمسامير القياسية بإحكام',
      'تركيب قواطع الفيوزات (Cutouts) ومانعات الصواعق في مواقعها الصحيحة',
      'توصيل تأريض المحول ومانعات الصواعق والحوامل المعدنية',
      'تركيب صندوق الجهد المنخفض أو القاطع التلقائي على العمود',
      'ترتيب جمبرات الجهد المتوسط والمنخفض وتحقيق المسافات العازلة',
      'سلامة ذراع تشغيل السكاكين الهوائية وإمكانية قفلها',
      'تركيب أغطية حماية الطيور على العوازل وأطراف المحول',
      'تثبيت لوحة رقم المحول واللوحات التحذيرية على العمود',
      'خلو المحول من أي تسريب للزيت وسلامة البوشنجات',
      'توثيق صور شاملة للمعدة المركبة على العمود من عدة زوايا'
    ]
  },
  {
    id: 'cat-16',
    key: 'excavations',
    title: 'أعمال الحفريات وتمديد الكابلات والردم والسفلتة',
    shortTitle: 'الحفريات والكابلات',
    description: 'تدقيق عمق الخنادق وفرش الرمل وتمديد الكابلات والشريط التحذيري والدمك',
    icon: 'excavations',
    itemCount: 15,
    items: [
      'مطابقة عمق وعرض خندق الحفر للمواصفات القياسية حسب مستوى الجهد',
      'تنظيف قاع الخندق من الحجارة والمواد الحادة قبل فرش الرمل',
      'فرش طبقة الرمل الناعم المعتمد أسفل وفوق الكابل بالسمك النظامي',
      'تمديد الكابلات دون التواء أو تقاطع مع الحفاظ على المسافات البينية',
      'تركيب مواسير الحماية (Ducts) في تقاطعات الطرق والمداخل',
      'رص بلاط الحماية الخرساني أو الأغطية البلاستيكية فوق الكابل',
      'تمديد الشريط التحذيري على العمق النظامي فوق مسار الكابل',
      'تركيب علامات تحديد مسار الكابل والمفاصل على سطح الأرض',
      'الردم على طبقات متتالية مع الرش بالمياه والدمك الميكانيكي',
      'إجراء اختبارات كثافة الدمك الميدانية عند الطلب',
      'إعادة السفلتة والأرصفة والانترلوك إلى وضعها الأصلي بجودة عالية',
      'توفير وسائل السلامة المرورية والحواجز والإضاءة التحذيرية أثناء العمل',
      'إزالة كافة مخلفات الحفر والأنقاض وتنظيف الموقع بالكامل',
      'استخراج وإجازة تصاريح الحفر وإخلاء الطرف من الجهات المعنية',
      'التوثيق الصوري المتسلسل لمراحل الحفر والتمديد والردم والسفلتة'
    ]
  },
  {
    id: 'cat-17',
    key: 'joints',
    title: 'وصلات ومفاصل الكابلات الأرضية (Cable Joints)',
    shortTitle: 'وصلات الكابلات',
    description: 'تدقيق تنفيذ وصلات الكابلات الأرضية للجهد المتوسط والمنخفض',
    icon: 'joints',
    itemCount: 10,
    items: [
      'تنفيذ الوصلة بواسطة فني كابلات (Jointer) مؤهل ومعتمد',
      'مطابقة نوع ومقاس علبة الوصلة لمقطع ونوع الكابل',
      'تجهيز وتقشير طبقات الكابل بالأبعاد الدقيقة حسب دليل الشركة الصانعة',
      'كبس الموصلات بالمكبس الهيدروليكي والقوالب المناسبة',
      'سلامة تطبيق أنابيب الانكماش الحراري أو البارد دون فقاعات هوائية',
      'استمرارية اتصال الشاشة المعدنية والتأريض (Screen Continuity)',
      'تركيب بطاقة بيانات الوصلة (Joint Tag) موضحاً عليها التاريخ واسم الفني',
      'حماية منطقة الوصلة بالرمل الناعم وبلاط الحماية وعلامة سطحية',
      'اجتياز الكابل لاختبار العزل والجهد بعد تنفيذ الوصلة',
      'توثيق صور مراحل تنفيذ الوصلة قبل وبعد الإغلاق والردم'
    ]
  },
  {
    id: 'cat-18',
    key: 'terminations',
    title: 'نهايات الكابلات والاختبارات النهائية (Terminations)',
    shortTitle: 'نهايات الكابلات',
    description: 'تدقيق تنفيذ رؤوس النهايات الداخلية والخارجية ونماذج الفحص',
    icon: 'terminations',
    itemCount: 10,
    items: [
      'سلامة تركيب رؤوس النهايات الداخلية أو الخارجية حسب موقع المعدة',
      'كبس النهايات الطرفية (Cable Lugs) بالمقاس الصحيح وعزم الشد القياسي',
      'تركيب الأبواط وأنابيب تنظيم المجال الكهربائي (Stress Control) بدقة',
      'تأريض الشاشة النحاسية أو التسليح بجديلة التأريض بشكل سليم',
      'تثبيت الكابل أسفل النهاية بمرابط غير مغناطيسية لمنع الإجهاد الميكانيكي',
      'مراعاة ألوان الفازات القياسية (أحمر، أصفر، أزرق) وتطابق التتابع',
      'تركيب الأغطية العازلة (Boots) على أطراف ربط الجهد المتوسط',
      'تثبيت بطاقة تعريف الكابل (Cable Tag) عند طرفي البداية والنهاية',
      'استيفاء ومطابقة نماذج الفحص والاختبار ونموذجي 190 و 200',
      'توثيق صور واضحة للنهايات بعد الربط النهائي داخل المعدة'
    ]
  }
];

export function createEmptyAuditColumnData(): WorkOrderAuditColumnData {
  return {
    mainStatus: 'قيد التدقيق',
    supportChecklist: {},
    evaluatedKeys: [],
    itemUpdatedAt: {},
    compliancePercentage: 0
  };
}

export function calculateCategoryAuditStatus(
  categoryData?: AuditSectionCategoryData,
  totalItemsCount: number = 10
): {
  status: 'ممتثل' | 'غير ممتثل' | 'لا ينطبق' | 'قيد التدقيق';
  compliantCount: number;
  nonCompliantCount: number;
  naCount: number;
  evaluatedCount: number;
  compliancePercentage: number;
} {
  if (!categoryData || !categoryData.items || typeof categoryData.items !== 'object') {
    if (categoryData?.status && categoryData.status !== 'قيد التدقيق') {
      return {
        status: categoryData.status,
        compliantCount: categoryData.status === 'ممتثل' ? totalItemsCount : 0,
        nonCompliantCount: categoryData.status === 'غير ممتثل' ? totalItemsCount : 0,
        naCount: categoryData.status === 'لا ينطبق' ? totalItemsCount : 0,
        evaluatedCount: totalItemsCount,
        compliancePercentage:
          categoryData.compliancePercentage ??
          (categoryData.status === 'ممتثل' || categoryData.status === 'لا ينطبق' ? 100 : 0)
      };
    }
    return {
      status: 'قيد التدقيق',
      compliantCount: 0,
      nonCompliantCount: 0,
      naCount: 0,
      evaluatedCount: 0,
      compliancePercentage: 0
    };
  }

  const values = Object.values(categoryData.items);
  if (values.length === 0) {
    return {
      status: 'قيد التدقيق',
      compliantCount: 0,
      nonCompliantCount: 0,
      naCount: 0,
      evaluatedCount: 0,
      compliancePercentage: 0
    };
  }

  let compliantCount = 0;
  let nonCompliantCount = 0;
  let naCount = 0;

  for (const v of values) {
    if (v === 'ممتثل') compliantCount++;
    else if (v === 'غير ممتثل') nonCompliantCount++;
    else if (v === 'لا ينطبق') naCount++;
  }

  const evaluatedCount = compliantCount + nonCompliantCount + naCount;
  const applicable = compliantCount + nonCompliantCount;
  const compliancePercentage =
    applicable > 0 ? Math.round((compliantCount / applicable) * 100) : naCount > 0 ? 100 : 0;

  let status: 'ممتثل' | 'غير ممتثل' | 'لا ينطبق' | 'قيد التدقيق' = 'قيد التدقيق';
  if (evaluatedCount > 0) {
    if (nonCompliantCount > 0) status = 'غير ممتثل';
    else if (compliantCount > 0) status = 'ممتثل';
    else if (naCount > 0) status = 'لا ينطبق';
  }

  return {
    status,
    compliantCount,
    nonCompliantCount,
    naCount,
    evaluatedCount,
    compliancePercentage
  };
}

export function calculateOverallAuditColumnSummary(
  columnData?: WorkOrderAuditColumnData | string | null
): {
  derivedMainStatus: 'مؤهل' | 'غير مؤهل' | 'قيد التدقيق';
  averageCompliance: number;
  compliantCategories: number;
  nonCompliantCategories: number;
  naCategories: number;
  pendingCategories: number;
} {
  if (!columnData) {
    return {
      derivedMainStatus: 'قيد التدقيق',
      averageCompliance: 0,
      compliantCategories: 0,
      nonCompliantCategories: 0,
      naCategories: 0,
      pendingCategories: AUDIT_CATEGORIES_META.length
    };
  }

  if (typeof columnData === 'string') {
    const s = columnData.trim();
    const isQual = !s.includes('غير') && (s.includes('مؤهل') || s.includes('مكتمل') || s.includes('معتمد'));
    const isDisqual = s.includes('غير');
    return {
      derivedMainStatus: isQual ? 'مؤهل' : isDisqual ? 'غير مؤهل' : 'قيد التدقيق',
      averageCompliance: isQual ? 100 : 0,
      compliantCategories: isQual ? AUDIT_CATEGORIES_META.length : 0,
      nonCompliantCategories: isDisqual ? 1 : 0,
      naCategories: 0,
      pendingCategories: isQual || isDisqual ? 0 : AUDIT_CATEGORIES_META.length
    };
  }

  if (Array.isArray(columnData.evaluatedKeys) && columnData.evaluatedKeys.length > 0 && columnData.supportChecklist) {
    let comp = 0;
    let nonComp = 0;
    let na = 0;
    for (const k of columnData.evaluatedKeys) {
      const val = columnData.supportChecklist[k];
      if (val === 'مكتمل') comp++;
      else if (val === 'لا ينطبق') na++;
      else nonComp++;
    }
    const applicable = comp + nonComp;
    const pct = applicable > 0 ? Math.round((comp / applicable) * 100) : na > 0 ? 100 : 0;
    const isQual = nonComp === 0 && (comp > 0 || na > 0);
    return {
      derivedMainStatus: isQual ? 'مؤهل' : 'غير مؤهل',
      averageCompliance: pct,
      compliantCategories: comp,
      nonCompliantCategories: nonComp,
      naCategories: na,
      pendingCategories: Math.max(0, 9 - columnData.evaluatedKeys.length)
    };
  }

  let compliantCategories = 0;
  let nonCompliantCategories = 0;
  let naCategories = 0;
  let pendingCategories = 0;
  let complianceSum = 0;
  let applicableCats = 0;

  for (const cat of AUDIT_CATEGORIES_META) {
    const catData = columnData[cat.key] as AuditSectionCategoryData | undefined;
    const res = calculateCategoryAuditStatus(catData, cat.itemCount);
    if (res.status === 'ممتثل') {
      compliantCategories++;
      complianceSum += res.compliancePercentage;
      applicableCats++;
    } else if (res.status === 'غير ممتثل') {
      nonCompliantCategories++;
      complianceSum += res.compliancePercentage;
      applicableCats++;
    } else if (res.status === 'لا ينطبق') {
      naCategories++;
    } else {
      pendingCategories++;
    }
  }

  const evaluatedTotal = compliantCategories + nonCompliantCategories + naCategories;
  if (evaluatedTotal === 0) {
    const explicitMain = columnData.mainStatus;
    if (explicitMain === 'مؤهل' || explicitMain === 'غير مؤهل') {
      return {
        derivedMainStatus: explicitMain,
        averageCompliance: explicitMain === 'مؤهل' ? 100 : 0,
        compliantCategories: explicitMain === 'مؤهل' ? 1 : 0,
        nonCompliantCategories: explicitMain === 'غير مؤهل' ? 1 : 0,
        naCategories: 0,
        pendingCategories: 0
      };
    }
    return {
      derivedMainStatus: 'قيد التدقيق',
      averageCompliance: 0,
      compliantCategories: 0,
      nonCompliantCategories: 0,
      naCategories: 0,
      pendingCategories: AUDIT_CATEGORIES_META.length
    };
  }

  const averageCompliance =
    applicableCats > 0 ? Math.round(complianceSum / applicableCats) : naCategories > 0 ? 100 : 0;
  const derivedMainStatus = nonCompliantCategories > 0 ? 'غير مؤهل' : 'مؤهل';

  return {
    derivedMainStatus,
    averageCompliance,
    compliantCategories,
    nonCompliantCategories,
    naCategories,
    pendingCategories
  };
}

export interface CategoryComplianceBreakdownItem {
  key: AuditCategoryKey;
  title: string;
  itemCount: number;
  pdcEvaluatedOrders: number;
  pdcCompliantOrders: number;
  pdcNonCompliantOrders: number;
  pdcComplianceRate: number;
  constEvaluatedOrders: number;
  constCompliantOrders: number;
  constNonCompliantOrders: number;
  constComplianceRate: number;
}

export function calculateAggregate18ChecklistsCompliance(orders: WorkOrder[]): {
  pdcComplianceRate: number;
  constComplianceRate: number;
  actualComplianceRate: number;
  ready155Rate: number;
  pdcEvaluatedOrders: number;
  pdcQualifiedOrders: number;
  pdcNonQualifiedOrders: number;
  constEvaluatedOrders: number;
  constQualifiedOrders: number;
  constNonQualifiedOrders: number;
  categoriesBreakdown: CategoryComplianceBreakdownItem[];
} {
  const emptyBreakdown: CategoryComplianceBreakdownItem[] = AUDIT_CATEGORIES_META.map(cat => ({
    key: cat.key,
    title: cat.title,
    itemCount: cat.itemCount,
    pdcEvaluatedOrders: 0,
    pdcCompliantOrders: 0,
    pdcNonCompliantOrders: 0,
    pdcComplianceRate: 0,
    constEvaluatedOrders: 0,
    constCompliantOrders: 0,
    constNonCompliantOrders: 0,
    constComplianceRate: 0
  }));

  if (!Array.isArray(orders) || orders.length === 0) {
    return {
      pdcComplianceRate: 0,
      constComplianceRate: 0,
      actualComplianceRate: 0,
      ready155Rate: 0,
      pdcEvaluatedOrders: 0,
      pdcQualifiedOrders: 0,
      pdcNonQualifiedOrders: 0,
      constEvaluatedOrders: 0,
      constQualifiedOrders: 0,
      constNonQualifiedOrders: 0,
      categoriesBreakdown: emptyBreakdown
    };
  }

  let pdcSum = 0;
  let pdcEvaluatedOrders = 0;
  let pdcQualifiedOrders = 0;
  let pdcNonQualifiedOrders = 0;

  let constSum = 0;
  let constEvaluatedOrders = 0;
  let constQualifiedOrders = 0;
  let constNonQualifiedOrders = 0;

  let ready155Count = 0;

  for (const wo of orders) {
    const pdcSummary = calculateOverallAuditColumnSummary(wo.pdcAudit);
    if (pdcSummary.derivedMainStatus !== 'قيد التدقيق') {
      pdcSum += pdcSummary.averageCompliance;
      pdcEvaluatedOrders++;
      if (pdcSummary.derivedMainStatus === 'مؤهل') pdcQualifiedOrders++;
      else pdcNonQualifiedOrders++;
    }

    const constSummary = calculateOverallAuditColumnSummary(wo.constructionAudit);
    if (constSummary.derivedMainStatus !== 'قيد التدقيق') {
      constSum += constSummary.averageCompliance;
      constEvaluatedOrders++;
      if (constSummary.derivedMainStatus === 'مؤهل') constQualifiedOrders++;
      else constNonQualifiedOrders++;
    }

    const s155 = String(wo.procedure155Status || '');
    if (!s155.includes('غير') && (s155.includes('مؤهل') || s155.includes('معتمد') || s155.includes('مكتمل'))) {
      ready155Count++;
    }
  }

  const categoriesBreakdown: CategoryComplianceBreakdownItem[] = AUDIT_CATEGORIES_META.map(cat => {
    let pdcCatEval = 0;
    let pdcCatComp = 0;
    let pdcCatNonComp = 0;
    let constCatEval = 0;
    let constCatComp = 0;
    let constCatNonComp = 0;

    for (const wo of orders) {
      if (wo.pdcAudit && typeof wo.pdcAudit === 'object') {
        const res = calculateCategoryAuditStatus(wo.pdcAudit[cat.key] as AuditSectionCategoryData | undefined, cat.itemCount);
        if (res.status !== 'قيد التدقيق') {
          pdcCatEval++;
          if (res.status === 'ممتثل' || res.status === 'لا ينطبق') pdcCatComp++;
          else pdcCatNonComp++;
        }
      }
      if (wo.constructionAudit && typeof wo.constructionAudit === 'object') {
        const res = calculateCategoryAuditStatus(wo.constructionAudit[cat.key] as AuditSectionCategoryData | undefined, cat.itemCount);
        if (res.status !== 'قيد التدقيق') {
          constCatEval++;
          if (res.status === 'ممتثل' || res.status === 'لا ينطبق') constCatComp++;
          else constCatNonComp++;
        }
      }
    }

    return {
      key: cat.key,
      title: cat.title,
      itemCount: cat.itemCount,
      pdcEvaluatedOrders: pdcCatEval,
      pdcCompliantOrders: pdcCatComp,
      pdcNonCompliantOrders: pdcCatNonComp,
      pdcComplianceRate: pdcCatEval > 0 ? Math.round((pdcCatComp / pdcCatEval) * 100) : pdcComplianceRateFallback(pdcEvaluatedOrders, pdcQualifiedOrders),
      constEvaluatedOrders: constCatEval,
      constCompliantOrders: constCatComp,
      constNonCompliantOrders: constCatNonComp,
      constComplianceRate: constCatEval > 0 ? Math.round((constCatComp / constCatEval) * 100) : pdcComplianceRateFallback(constEvaluatedOrders, constQualifiedOrders)
    };
  });

  const pdcComplianceRate = pdcEvaluatedOrders > 0 ? Math.round(pdcSum / pdcEvaluatedOrders) : 0;
  const constComplianceRate = constEvaluatedOrders > 0 ? Math.round(constSum / constEvaluatedOrders) : 0;
  const totalEvaluated = pdcEvaluatedOrders + constEvaluatedOrders;
  const actualComplianceRate =
    totalEvaluated > 0 ? Math.round((pdcSum + constSum) / totalEvaluated) : 0;
  const ready155Rate = orders.length > 0 ? Math.round((ready155Count / orders.length) * 100) : 0;

  return {
    pdcComplianceRate,
    constComplianceRate,
    actualComplianceRate,
    ready155Rate,
    pdcEvaluatedOrders,
    pdcQualifiedOrders,
    pdcNonQualifiedOrders,
    constEvaluatedOrders,
    constQualifiedOrders,
    constNonQualifiedOrders,
    categoriesBreakdown
  };
}

function pdcComplianceRateFallback(evaluated: number, qualified: number): number {
  return evaluated > 0 ? Math.round((qualified / evaluated) * 100) : 0;
}

export function formatOrderAudit18SummaryText(
  rawAudit?: WorkOrderAuditColumnData | string | null
): {
  mainStatus: 'مؤهل' | 'غير مؤهل' | 'قيد التدقيق' | '';
  compactBadgeText: string;
  detailedText: string;
} {
  if (!rawAudit) {
    return { mainStatus: '', compactBadgeText: '', detailedText: '' };
  }
  const summary = calculateOverallAuditColumnSummary(rawAudit);
  if (summary.derivedMainStatus === 'قيد التدقيق') {
    return { mainStatus: '', compactBadgeText: '', detailedText: '' };
  }
  const compactBadgeText = `${summary.derivedMainStatus} (${summary.averageCompliance}%)`;
  const detailedText = `${summary.derivedMainStatus} - نسبة الامتثال ${summary.averageCompliance}%`;
  return {
    mainStatus: summary.derivedMainStatus,
    compactBadgeText,
    detailedText
  };
}

export function sync18CategoriesFromPrimarySupportChecklist(
  existingColData: WorkOrderAuditColumnData,
  nextValues: Record<string, string>,
  nextEvaluatedKeys: string[],
  nowIso: string
): WorkOrderAuditColumnData {
  const updated: WorkOrderAuditColumnData = {
    ...existingColData
  };

  const toCategoryData = (key: string): AuditSectionCategoryData | undefined => {
    if (!nextEvaluatedKeys.includes(key)) return undefined;
    const rawVal = nextValues[key];
    const status: 'ممتثل' | 'غير ممتثل' | 'لا ينطبق' =
      rawVal === 'مكتمل' ? 'ممتثل' : rawVal === 'لا ينطبق' ? 'لا ينطبق' : 'غير ممتثل';
    return {
      status,
      compliancePercentage: status === 'ممتثل' || status === 'لا ينطبق' ? 100 : 0,
      evaluatedAt: nowIso
    };
  };

  const meterCat = toCategoryData('meterPhotoDocumentation');
  if (meterCat) updated.boxesAndMeters = meterCat;

  const excavCat = toCategoryData('excavationPhotoDocumentation');
  if (excavCat) updated.excavations = excavCat;

  const equipCat = toCategoryData('equipmentPhotoDocumentation');
  if (equipCat) updated.stationRoom = equipCat;

  const overheadCat = toCategoryData('overheadPhotoDocumentation');
  if (overheadCat) updated.overheadPoles = overheadCat;

  const formsCat = toCategoryData('consultantForms');
  if (formsCat) updated.joints = formsCat;

  const inspCat = toCategoryData('inspectionForm');
  if (inspCat) updated.terminations = inspCat;

  return updated;
}
